/* ============ Состояние ============ */
const STORAGE_KEY = 'study_tasks_v1';

/** @typedef {{id:string,title:string,description:string,priority:'low'|'medium'|'high',deadline:string,done:boolean,createdAt:number}} Task */

let tasks = [];
let currentFilter = 'all';
let currentSort = 'created';

/* ============ DOM ============ */
const $ = (sel) => document.querySelector(sel);

const form = $('#task-form');
const formTitle = $('#form-title');
const taskIdInput = $('#task-id');
const titleInput = $('#title');
const descInput = $('#description');
const priorityInput = $('#priority');
const deadlineInput = $('#deadline');
const submitBtn = $('#submit-btn');
const cancelBtn = $('#cancel-btn');

const taskList = $('#task-list');
const emptyMsg = $('#empty-message');

const statTotal = $('#stat-total');
const statDone = $('#stat-done');
const statActive = $('#stat-active');

const filtersEl = $('#filters');
const sortSelect = $('#sort-select');

/* ============ Работа с localStorage ============ */
function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    tasks = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(tasks)) tasks = [];
  } catch {
    tasks = [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

/* ============ Утилиты ============ */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const PRIORITY_LABEL = { low: 'Низкий', medium: 'Средний', high: 'Высокий' };
const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 };

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d)) return '';
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function isOverdue(task) {
  if (!task.deadline || task.done) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(task.deadline + 'T00:00:00') < today;
}

/* ============ Рендер ============ */
function getVisibleTasks() {
  let list = [...tasks];

  // Фильтр
  if (currentFilter === 'active') list = list.filter(t => !t.done);
  else if (currentFilter === 'done') list = list.filter(t => t.done);
  else if (currentFilter === 'high') list = list.filter(t => t.priority === 'high');

  // Сортировка
  if (currentSort === 'deadline') {
    list.sort((a, b) => {
      if (!a.deadline && !b.deadline) return 0;
      if (!a.deadline) return 1;
      if (!b.deadline) return -1;
      return a.deadline.localeCompare(b.deadline);
    });
  } else if (currentSort === 'priority') {
    list.sort((a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]);
  } else {
    list.sort((a, b) => b.createdAt - a.createdAt);
  }

  return list;
}

function render() {
  const visible = getVisibleTasks();
  taskList.innerHTML = '';

  if (visible.length === 0) {
    emptyMsg.hidden = false;
  } else {
    emptyMsg.hidden = true;
    const fragment = document.createDocumentFragment();
    visible.forEach(task => fragment.appendChild(createTaskElement(task)));
    taskList.appendChild(fragment);
  }

  updateStats();
}

function createTaskElement(task) {
  const el = document.createElement('article');
  el.className = `task task--${task.priority}${task.done ? ' task--done' : ''}`;
  el.dataset.id = task.id;

  // Чекбокс
  const check = document.createElement('input');
  check.type = 'checkbox';
  check.className = 'task__check';
  check.checked = task.done;
  check.title = 'Отметить как выполненную';
  check.addEventListener('change', () => toggleDone(task.id));

  // Тело
  const body = document.createElement('div');
  body.className = 'task__body';

  const title = document.createElement('h3');
  title.className = 'task__title';
  title.textContent = task.title;
  body.appendChild(title);

  if (task.description) {
    const desc = document.createElement('p');
    desc.className = 'task__desc';
    desc.textContent = task.description;
    body.appendChild(desc);
  }

  const meta = document.createElement('div');
  meta.className = 'task__meta';

  const prio = document.createElement('span');
  prio.className = `badge badge--${task.priority}`;
  prio.textContent = PRIORITY_LABEL[task.priority];
  meta.appendChild(prio);

  if (task.deadline) {
    const date = document.createElement('span');
    date.className = 'badge ' + (isOverdue(task) ? 'badge--overdue' : 'badge--date');
    date.textContent = (isOverdue(task) ? '⚠ ' : '📅 ') + formatDate(task.deadline);
    meta.appendChild(date);
  }

  body.appendChild(meta);

  // Кнопки
  const actions = document.createElement('div');
  actions.className = 'task__actions';

  const editBtn = document.createElement('button');
  editBtn.className = 'icon-btn';
  editBtn.title = 'Редактировать';
  editBtn.textContent = '✏️';
  editBtn.addEventListener('click', () => startEdit(task.id));

  const delBtn = document.createElement('button');
  delBtn.className = 'icon-btn icon-btn--del';
  delBtn.title = 'Удалить';
  delBtn.textContent = '🗑️';
  delBtn.addEventListener('click', () => deleteTask(task.id));

  actions.appendChild(editBtn);
  actions.appendChild(delBtn);

  el.appendChild(check);
  el.appendChild(body);
  el.appendChild(actions);

  return el;
}

function updateStats() {
  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  statTotal.textContent = total;
  statDone.textContent = done;
  statActive.textContent = total - done;
}

/* ============ CRUD ============ */
function handleSubmit(e) {
  e.preventDefault();

  const title = titleInput.value.trim();
  if (!title) {
    titleInput.focus();
    titleInput.style.borderColor = 'var(--danger)';
    setTimeout(() => (titleInput.style.borderColor = ''), 1200);
    return;
  }

  const id = taskIdInput.value;

  if (id) {
    // Редактирование
    const task = tasks.find(t => t.id === id);
    if (task) {
      task.title = title;
      task.description = descInput.value.trim();
      task.priority = priorityInput.value;
      task.deadline = deadlineInput.value;
    }
  } else {
    // Создание
    tasks.push({
      id: uid(),
      title,
      description: descInput.value.trim(),
      priority: priorityInput.value,
      deadline: deadlineInput.value,
      done: false,
      createdAt: Date.now(),
    });
  }

  saveTasks();
  resetForm();
  render();
}

function toggleDone(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  task.done = !task.done;
  saveTasks();
  render();
}

function deleteTask(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  if (!confirm(`Удалить задачу «${task.title}»?`)) return;
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
  if (taskIdInput.value === id) resetForm();
  render();
}

function startEdit(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;

  taskIdInput.value = task.id;
  titleInput.value = task.title;
  descInput.value = task.description;
  priorityInput.value = task.priority;
  deadlineInput.value = task.deadline || '';

  formTitle.textContent = 'Редактирование задачи';
  submitBtn.textContent = 'Сохранить';
  cancelBtn.hidden = false;

  titleInput.focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
  form.reset();
  taskIdInput.value = '';
  priorityInput.value = 'medium';
  formTitle.textContent = 'Новая задача';
  submitBtn.textContent = 'Добавить';
  cancelBtn.hidden = true;
}

/* ============ Обработчики ============ */
form.addEventListener('submit', handleSubmit);
cancelBtn.addEventListener('click', resetForm);

filtersEl.addEventListener('click', (e) => {
  const btn = e.target.closest('.chip');
  if (!btn) return;
  currentFilter = btn.dataset.filter;
  filtersEl.querySelectorAll('.chip').forEach(c => c.classList.toggle('is-active', c === btn));
  render();
});

sortSelect.addEventListener('change', () => {
  currentSort = sortSelect.value;
  render();
});

/* ============ Инициализация ============ */
loadTasks();
render();